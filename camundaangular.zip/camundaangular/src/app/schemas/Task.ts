export class Task {
  id: string;
  name: string;
  key: string;
}
